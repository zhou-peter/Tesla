console.log("popup script loaded");
//region {calls}
document.addEventListener("DOMContentLoaded",function(dcle) {

//alert("Alert on Dom loaded");
});
//end-region