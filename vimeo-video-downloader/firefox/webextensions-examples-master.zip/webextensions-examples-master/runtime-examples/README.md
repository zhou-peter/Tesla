## What it does

Trigger an install notification when you install it. On the browser action text is
shown showing when the background page was last loaded in minutes and seconds.

Clicking the browser action triggers a reload and updates the background page load time.

The notifications show the version of the extension by fetching the manifest.

## What it shows

Demonstration of some runtime and notification APIs.

Icon is from: https://www.iconfinder.com/icons/172151/run_icon#size=128
