# Top Sites

## What it does

This extension replaces the built-in page shown when the user opens a new tab without specifying a page to load (for example, when the user presses Ctrl+T). The replacement page is populated with links taken from the topSites API.

# What it shows

How to use chrome_url_overrides and the topSites API.
