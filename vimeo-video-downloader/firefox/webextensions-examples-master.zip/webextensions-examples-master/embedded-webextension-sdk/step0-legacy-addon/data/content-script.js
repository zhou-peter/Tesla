self.port.emit("notify-attached-tab", window.location.href);
