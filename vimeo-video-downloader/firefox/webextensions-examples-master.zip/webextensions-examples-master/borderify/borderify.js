/*
Just draw a border round the document.body.
*/
document.body.style.border = "5px solid red";
